
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;


public class Mob extends Rectangle {
     public int mobSize = 52; 
     public int mobId = Value.mobAir;
     
     public int upward = 0 , downward = 1,right =2,left = 3;
     public int direction = right;
     public int mobWalk =0;
     public boolean inGame = false;
      public int xC ,yC ;  
      public boolean hasUpward = false;
      public boolean hasDownward = false;
      public boolean hasRight = false;
      public boolean hasLeft =false;
      public int health ;
      public int healthSpace=3 , healthHeight =6;
     
     
    public Mob()
    {
        x+=1;
    }
    
    public void spawnMob(int mobId)
    {
        for (int y=0;y<Screen.room.block.length;y++)
        {
            if (Screen.room.block[y][0].groundId == Value.groundRoad)
            {
                setBounds(Screen.room.block[y][0].x,Screen.room.block[y][0].y , mobSize , mobSize);
                xC =0;
                yC =y;
            }
        }
        this.mobId = mobId;
        inGame = true;
        this.health = mobSize;
    }
    public void delete()
    {
        inGame=false;
        direction = right;
        mobWalk = 0;
    }
    public void looseHealth()
    {
        Screen.health -=10;
    }
    public void loseHealth(int i)
    {
        health -=i;
        checkDeath();
    }
    public void checkDeath()
    {
        if (health ==0) 
        {
            delete();
        }
    }
    public boolean isDead()
    {
        if (inGame)
        {
            return false;
        }
        else 
        {
            return true;
        }
    }
     public int walkFrame=0 , speedX = 3;
    public void physic()
    {
        if (walkFrame > speedX)
        {
            if (direction == right)
            {
                x+=1;
            }
            else if (direction  ==  upward )
            {
                --y;
            }
            else if (direction == downward)
            {
                ++y;
            }
            else if (direction == left)
            {
                x--;
            }
         mobWalk+=1;
         if (mobWalk==Screen.room.blockSize)
         {
             if (direction == right)
            {
                xC+=1;
                hasRight = true;
            }
            else if (direction  ==  upward )
            {
                --yC;
                hasUpward = true;
            }
            else if (direction == downward)
            {
                ++yC;
                hasDownward = true;
            }
            else if (direction == left)
            {
                xC -=1;
                hasLeft = true;
            }
             if (!hasUpward)
             {
                  try{
                if (Screen.room.block[yC+1][xC].groundId == Value.groundRoad)
                    {
                        direction = downward;
                    }
                    } catch(Exception e) {}
             }
            
             if (!hasDownward)
             {
                try{
                   if (Screen.room.block[yC-1][xC].groundId == Value.groundRoad)
                     {
                      direction = upward;
                     }
                   
                     } catch(Exception e) {}
             }
             if (!hasLeft)
             {
             try{
                 if (Screen.room.block[yC][xC+1].groundId == Value.groundRoad)
                 {
                     direction = right;
                }
                } catch(Exception e) {}
             }
             
             if (!hasRight)
             {
             try{
                 if (Screen.room.block[yC][xC-1].groundId == Value.groundRoad)
                 {
                     direction = left;
                }
                } catch(Exception e) {}
             }
             if (Screen.room.block[yC][xC].airId== Value.airCave)
             {
                 delete();
                 looseHealth();
             }
             hasUpward = false;
             hasDownward = false;
             hasLeft = false;
             hasRight = false;
             
             mobWalk=0;
         }
         walkFrame =0;
        }
        else 
        {
            walkFrame ++;
        }
    }
    public void draw(Graphics g)
    {
        if (inGame)
        {
            g.drawImage(Screen.tileset_mob[mobId],x,y,width,height,null);
            
            g.setColor(new Color(180,50,50));
            g.fillRect(x,y-(healthSpace + healthHeight),width,healthHeight);
            
            g.setColor(new Color(50,180,50));
            g.fillRect(x,y-(healthSpace + healthHeight),health,healthHeight);
            
            g.setColor(new Color(0,0,0));
            g.drawRect(x,y-(healthSpace + healthHeight),health-1,healthHeight-1);
        }
    }
}
